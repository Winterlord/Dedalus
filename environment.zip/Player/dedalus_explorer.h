
/*
  Enumeration for the different moves Theseus may make.
 */
enum compass {North, East, South, West, None};
typedef enum compass Move;

/*
  The already explored map is recorded in an ExpTree (Exploration Tree) t, i.e., a pointer on a tree node.
  At the beginning (dedalus entrance), the tree contains a single node whose move is None (t->m=None). From this node, the current exploration of the dedalus whose first move is North is accessible through the north subtree (t->north), and similarly for East, South and West.
 */
struct Node {Move m; struct Node * north; struct Node * east; struct Node * south; struct Node * west;};
typedef struct Node * ExpTree;

/*
  Linked list used to model a path of moves.
 */
struct link {Move m; struct link * next;};
typedef struct link * string;
